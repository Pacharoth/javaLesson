//print only OddNumber
public class Odd {
    public static void main(String[] args) {
        int i=0;
        while (i<=5000) {
            if(i%2!=0){
                System.out.print(i+"\t");
            }
            i++;
        }
    }
}
